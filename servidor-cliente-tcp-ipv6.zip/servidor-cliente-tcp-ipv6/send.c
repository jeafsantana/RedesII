#include <stdio.h>
#include <string.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <arpa/inet.h>

#define PORT_NUMBER     5000
#define SERVER_ADDRESS  "2001:1bcd:123:1:6451:ad8e:3abc:6c78"

void envia(int s, char *message)
{
    char buf[8192];

    strncpy(buf, message, sizeof(buf));
    send(s, buf, strlen(buf), 0);
    recv(s, buf, 8192, 0);
    strtok(buf, "\n");
    puts(buf);
}


int main(int argc, char **argv){
    int s;
    struct sockaddr_in6 addr;

    s = socket(AF_INET6, SOCK_STREAM, 0);
    addr.sin6_family = AF_INET6;
    addr.sin6_port = htons(PORT_NUMBER);
    inet_pton(AF_INET6, SERVER_ADDRESS, &addr.sin6_addr);
    connect(s, (struct sockaddr *)&addr, sizeof(addr));

    envia(s, "oi\n");
    envia(s, "tudo\n");
    envia(s, "bom?\n");

    close(s);
    return 0;
}
